package assignment;

public class P_Calender {
	public static void printCalendar(int month, int year) {
	
	String[] s1= {"sun","mon","tue","wed","thu","fri","sat",};
	int num=1;
	for( int i=0;i<7;i++)
	{
		System.out.print("\t" +s1[i]);
	}
	
for(int j=1; j<6;j++) {
	for(int k=1;k<7;k++) {
	System.out.print(num);
	num++;
	if(num>31) {break;}
	}
}
	
}

 public static void main(String[] args)
 {
	 printCalendar()
 }
	 
 }
	

	
		
	