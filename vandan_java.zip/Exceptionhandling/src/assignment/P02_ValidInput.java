package assignment;

import java.util.Scanner;

public class P02_ValidInput {
	
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the  string");
	     String  input=sc.nextLine();
	
		public static void isint(input)
		{
			
		

		
		 
	     
	     
   
	
		
		
		
	if(isint(input))
	{
		
	}
	
	

	
	



	
