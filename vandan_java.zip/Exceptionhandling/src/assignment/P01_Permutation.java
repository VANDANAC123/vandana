package assignment;

public class P01_Permutation {
	
	public static void printAllCombinations(String word) {
		
		System.out.println(word);
		
	char[] a=new char[3];
		for(int i, j ;i< word.length();i++)
		{
           char temp;
			temp=char[i];
			
		}
			
			
			
		
	
		
	}
	
	public static void main(String[] args) {
		
		String s1="win";
		printAllCombinations(s1);
		
	}

}
