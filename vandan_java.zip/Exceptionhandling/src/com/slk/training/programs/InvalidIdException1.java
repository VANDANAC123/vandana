package com.slk.training.programs;

public class InvalidIdException1 {

	public InvalidIdException1() {
		// TODO Auto-generated constructor stub
	}

}
