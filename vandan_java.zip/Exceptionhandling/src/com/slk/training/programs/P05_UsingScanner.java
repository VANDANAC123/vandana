package com.slk.training.programs;

import java.util.Scanner;

public class P05_UsingScanner {
	
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("ENTER THE id OF PRODUCT");
	     String  id=sc.nextLine();
		
		System.out.println("ENTER THE name OF PRODUCT");
		String name=sc.nextLine();
		
		System.out.println("ENTER THE price OF PRODUCT");
		String price=sc.nextLine();
		
		System.out.println("name="+name);
		System.out.println("price="+price);
		System.out.println("id="+id);
		
	}
}


		

