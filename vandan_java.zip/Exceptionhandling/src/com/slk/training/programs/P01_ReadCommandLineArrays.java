package com.slk.training.programs;

public class P01_ReadCommandLineArrays {
	//command to execute this prgm on the command (terminal)
	
	public static void main(String[] args) {
		System.out.printf("there are %d arguments\n",args.length);
		for (int i = 0; i < args.length; i++) {
			System.out.printf("args[%d]=%s\n",i,args[i]);
		}
	}

}
