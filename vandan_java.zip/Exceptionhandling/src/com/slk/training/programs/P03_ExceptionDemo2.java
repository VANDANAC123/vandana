package com.slk.training.programs;

public class P03_ExceptionDemo2 {
	public static void main(String[] args) {
		try {
			String input1=args[0];
			String input2=args[1];
			
			int n=Integer.parseInt(input1);
			int d=Integer.parseInt(input2);
			
			
			int q=n/d,r=n%d;
			
			System.out.printf("quotient of %d/%d is %d and remainder is %d\n  ", n,d,q,r);
		} catch (NumberFormatException e) {
			System.out.println("oops! exception ");}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("oops! not found ");
			return;
			
			
			
		}
		catch(ArithmeticException e)
		{
			System.out.println("oops! wrong ");
			System.exit(0);
		}
		finally {
			System.out.println("from the final block ");
		}
			
		
		System.out.printf("end of main");
	}

}
