package com.slk.training.programs;

public class InvalidnameException extends RuntimeException {

	public InvalidnameException() {
		// TODO Auto-generated constructor stub
	}

	public InvalidnameException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InvalidnameException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidnameException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidnameException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
