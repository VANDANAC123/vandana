package com.slk.training.programs;

import RTE;

public class InvalidIdException3 extends RTE {

}
