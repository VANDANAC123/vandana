package com.slk.training.programs;

public class InvalidIdException {

	public InvalidIdException() {
		// TODO Auto-generated constructor stub
	}

}
