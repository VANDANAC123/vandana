package com.slk.training.programs;
import com.slk.training.entity.Product;
import com.slk.training.programs.InvalidIdException4;
import com.slk.training.programs.InvalidnameException;
import com.slk.training.programs.InvalidpriceException;

public class P04_HandlingException {
	public static void main(String[] args) {
		Product p;
		try {
			p = new Product();
			 p.setId(12);
			 p.setName("vandana");
			 p.setPrice(123);
		} catch (InvalidIdException4 e) {
			System.out.println("invalid  id");
		}
		catch (InvalidnameException e) {
			System.out.println("invalid  name");
		} 
		catch (InvalidpriceException e) {
			System.out.println("invalid  price");
		}  
		 
	}
	

}
