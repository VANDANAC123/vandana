package com.slk.training.programs;

import com.slk.training.utils.KeyBoardUtility;

public class P06_UsingKeyboardUtil {

	public P06_UsingKeyboardUtil() {
		
	}
	public static void main(String[] args) {
		
		int age=KeyBoardUtility.getInt("ENTER THE AGE");
		String name=KeyBoardUtility.getString("ENTER THE NAME");
		double height =KeyBoardUtility.getDouble("enter the height");
		
		System.out.println("name="+name);
		System.out.println("age="+age);
		System.out.println("height="+height);
		
		
	}

}
