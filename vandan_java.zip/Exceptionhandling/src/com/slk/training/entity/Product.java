package com.slk.training.entity;

public class Product {
	private int id;// id cannot be -ve
	private String name;//name cannot be -ve
	private double price;//price cannot be -ve
	
	public Product()
	{
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		if(id<0) {
		throw new RuntimeException("invalid id;cannot be negative");	
			
		}
		this.id = id;
	}
	

	public String getName() {
		return name;
	}

	public void setName(String name) {
		if(name==null || name.length()<2 || name.length()>50) {
			throw new RuntimeException("name cannot be blank:");
		}
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		if(price <0)
		{
			throw new RuntimeException("invalid price cannot be negative");
		}
		this.price = price;
	}
	
	}


