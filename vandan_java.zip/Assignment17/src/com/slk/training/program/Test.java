package com.slk.training.program;

import  com.slk.training.entity.Shape;
import  com.slk.training.program.Rectangle;
import  com.slk.training.program.Circle;
import  com.slk.training.program.Square;

public class Test {
	public static void main(String[] args) {
	 Shape[] objects=
		 {
				 //new Shape("red",true),
				 new Circle(12.2),
				 new Rectangle(12.2,12.2),
				 new Square(13.2)
		 };
	 
	 for(Shape s1:objects)
		if (s1 instanceof Circle ){
			Circle c=(Circle)s1;
			System.out.println(" enter the area and the perimeter:"+c.getArea()+"  "+c.getPerimeter());
		}
	
		else if (s1 instanceof Rectangle ){
				Rectangle r=(Rectangle)s1;
				System.out.println(" enter the area and the perimeter:"+r.getArea()+"  "+r.getPerimeter());
			}
		 
	
		else if (s1 instanceof Square){
				Square s=(Square)s1;
				System.out.println(" enter the area and the perimeter:"+s.getArea()+"  "+s.getPerimeter());
			}
	}
}
		 
