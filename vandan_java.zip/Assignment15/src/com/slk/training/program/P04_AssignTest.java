package com.slk.training.program;
import com.slk.training.entity.Circle;

import com.slk.training.program.Cylinder;

public class P04_AssignTest {
	public static void main(String[] args) {
		
		Circle[] circles = {
				new Cylinder(12.34),
				new Cylinder(12.34, 10.0),
				new Cylinder(12.34,  "blue",10.0)
			};
		for(Circle  c: circles)
		{
			System.out.println("tne area and volume is"+c.getArea()+"  "+c.getvolume());
		}
	}

}
