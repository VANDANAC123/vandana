package com.slk.training.program;

import java.util.Scanner;

public class Assign18 {
	
	Scanner sc=new Scanner(System.in);
	
	public static boolean isInteger(String input)
	{
		try {
	
	Integer.parseInt(input);
		}
		catch(Exception ex)
		{
			return false;
		}
		
	return true;
		}

 public static void main(String[] args)
 {
	int icount=0;
	int scount=0;
	int sum=0;
	
	
	
 }
}
	
		
	

	