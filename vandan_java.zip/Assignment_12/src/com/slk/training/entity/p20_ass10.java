package com.slk.training.entity;

public class p20_ass10 {
	
	public static String inWords(int num) { 
		
	   String[] a={" ","one","two","three","four","five","six","seven","eight","nine","ten"};
	   String[] b={" "," ","twenty","thirty","forty","fifty","sixty","seventy","eighty","ninty"};
	   String[] c= {"ten ","eleven","twelve","thirteen","fourteen","fifteen","sixteen","seventeen","eighteen","nineteen"};
	   	if(num<10)
	   	{
	   		return a[num];
	   	}
	   		
	   		else if(num>=10 && num<20)
	   		{
	   			return c[num%10];
	   		}
	   		else if(num>=20 && num<100)
	   		{
	   			return b[num/10]+" "+a[num%10];
	   		}
	   		else if(num>=100 && num<1000)
	   		{
	   			return a[num/100]+"hundred"+inWords(num%100);
	   		}
	   		else if(num>=1000 && num<10000)
	   		{
	   			return a[num/1000]+"thousand"+inWords(num%1000);
	   		}
	   		else if(num>=10000 && num<=100000) {
	   			return b[num/10000]+inWords(num%10000);
	   		}
	   		else if(num>=100000 && num<=1000000) {
	   			return a[num/100000]+"lakh"+inWords(num%100000);
	   		}
	   		else if(num>=1000000 && num<=10000000) {
	   			return b[num/1000000]+inWords(num%1000000);
	   		}
	   			
	   	return null;
	   	   	
	
	
}

public static void main(String[] args) {
	int a=20200;
	String s1=(inWords(a));
	System.out.println(s1);
}
}