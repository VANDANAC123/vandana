package com.slk.training.programs;
import java.util.LinkedList;
import java.util.List;

public class P01_usingLists {
	
	public static void main(String[] args) {
		List<String> names =new LinkedList<String>();
		names.add("vandana");
		names.add("laksh");
		names.add("priya");
		names.add("shravs");
		
		
		
		names.remove("vandana");
		System.out.println("after  removing name"+names);
		names.remove(1);
		System.out.println("after  removing value at index 1:"+names);
		names.add(0,"vandana");
		System.out.println("after  inserting at index 0"+names);
		names.set(1, "shetty");// replacing laksh with shetty;
		System.out.println("after  setting value at the index 1:"+names);
		
		
		 List  objects = new LinkedList();
		 objects .add(123);
		 objects .add("vandana");
		 objects .add(12.4);
		 
		 
		 System.out.println(objects);
		 for(Object obj:objects) {
			 System.out.println(obj+" is aof type"+obj.getClass()); 
		 }
	}
		
		
	}


