package com.slk.training.programs;

import java.util.TreeSet;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class P02_UsingSets {
	public static void main(String[] args) {
		
		Set<Book> books=new TreeSet<Book>();
		Book b1=new Book(1,"let us see",299,125);
		Book b2=new Book(1,"let us see",299,125);
		System.out.println("b1.hashset()="+ b1.hashCode());
		System.out.println("books.size(),"+ b2.hashCode());
		System.out.println("books.size(),"+ b1.equals(b2));
		
		
		books.add(new Book(1,"let us c",299,125));
		books.add(new Book(1,"let us wait ",399,175));
		books.add(new Book(1,"let us go",299,125));
		books.add(new Book(1,"let us c ",299,125));
		books.add(new Book(1,"let us do",899,500));
		System.out.println("books.size(),"+ books.size());
		for(Book b:books) {
			System.out.println(b);
		}
		
		Set<Integer> nums =new TreeSet<Integer>();
		nums.add(123);
		nums.add(12);
		nums.add(222);
		nums.add(123);
		nums.add(99);
		nums.add(222);
		nums.add(12);
		nums.add(789);
		System.out.println(nums);
		// hashset--->[99,789,123,12,222]
		// get data using enhanced for loop(for each loop)
		System.out.println("data using enhanced for loop");
		for(Integer n:nums)
		{
			System.out.println(n);
			
		}
		// prior to the jdk 1.5 this was the only way of accessing the elements from a set
		System.out.println("number using iterations");
		Iterator<Integer> itr = nums.iterator();
		while(itr.hasNext()) {
			Integer n = itr.next();
			System.out.println(n);
		}
		
	}

}
