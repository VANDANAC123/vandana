package com.slk.training.programs;

import java.util.LinkedHashMap;
import java.util.Map;
import com.slk.training.programs.Book;

public class P03_UsingMaps {
	public static void main(String[] args) {
		 Map<Integer,Book> books= new LinkedHashMap<>();
		 Book b1;
		 b1= new Book(67823,"java unleased",456.3,300);
		 books.put(b1.getId(), b1);
		 
		 b1= new Book(12,"authentic java",299,150);
		 books.put(b1.getId(), b1);
		 
		 b1= new Book(67823,"complete java guide",999.3,500);
		 books.put(b1.getId(), b1);
		 
		 b1= new Book(678,"java complete reference",459.3,300);
		 books.put(b1.getId(), b1);
		 
		 b1= new Book(222,"java whitebook",289.3,120);
		 books.put(b1.getId(), b1);
		 
		 System.out.println("number of books,"+books.size());
		 System.out.println("the books are");
		 for(Book b:books.values()) {
			 System.out.println(b);
		 }
		 
		 
	}

}
