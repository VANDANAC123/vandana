package com.slk.training.programs;


import java.io.BufferedReader;

import java.io.FileReader;
import java.io.IOException;
public class P02_ReadFromTextFile {
	static String filename="src/com/slk/training/programs/P02_ReadFromTextFile.java";
	
	public static void main(String[] args) {
		try(
				FileReader file=new FileReader(filename);
				BufferedReader in=new BufferedReader(file);
	){
			
		
	String line;
		while((line=in.readLine())!=null) {
			System.out.println(line);
		}
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		
	}
	
	

	
	public static void ex01(String[] args) throws IOException {
		String filename = "src/com/slk/training/programs/P02_ReadFromTextFile.java";
		FileReader in=new FileReader(filename);
		int ch;
		while((ch=in.read()) !=-1) {
			System.out.print((char)ch);
		}
		System.out.println();
	
		//in.close();
		
		
	}

}
