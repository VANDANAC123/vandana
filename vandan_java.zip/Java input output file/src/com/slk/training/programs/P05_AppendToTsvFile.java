package com.slk.training.programs;


import java.io.FileWriter;
import java.io.PrintWriter;

import com.slk.training.utils.KeyBoardUtility;

public class P05_AppendToTsvFile {
	
	
	public static void main(String[] args) {
		
		
		
String filename="people.csv";
		
		try(
				FileWriter writer=new FileWriter(filename,true);
				PrintWriter out=new PrintWriter(writer)){
	
          String name=KeyBoardUtility.getString("enter the name:");
          String email=KeyBoardUtility.getString("enter the email:");
          String city=KeyBoardUtility.getString("enter the city:");
          
          out.printf("\n%s\t%s\t%s", name,email,city);
		
		}
		catch(Exception ex) {
	}
		System.out.println("data appended to the file");
	}
}


