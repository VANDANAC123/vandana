package com.slk.training.programs;

import java.io.BufferedReader;
import java.io.FileReader;

public class P04_ReadTvsFile {
	
	public static void main(String[] args) {
		
		
		String filename="people.csv";
		
		try(
				FileReader file=new FileReader(filename);
				BufferedReader in=new BufferedReader(file);
	){
			
		
	String line;
	in.readLine();
		while((line=in.readLine())!=null) {
			String[] arr=line.split("\t");
			System.out.println("name      :"+arr[0]);
			System.out.println("email      :"+arr[1]);
			System.out.println("city     :"+arr[2]);
			System.out.println();
			
		}
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		
	}
	}


