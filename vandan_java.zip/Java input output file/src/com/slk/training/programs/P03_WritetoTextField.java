package com.slk.training.programs;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import com.slk.training.utils.KeyBoardUtility;

public class P03_WritetoTextField {
	
	public static void main(String[] args) throws IOException {
	String filename="names.txt";
	FileWriter file=new FileWriter(filename,true);
	
	PrintWriter out =new PrintWriter(file);
	
	while(true)
	{
		String input=KeyBoardUtility.getString("enter a name(or blank to stop)");
		if(input.trim().equals("")) {
			break;
		}
		out.println(input);
	}
	out.close();
	file.close();
	
	System.out.println(" file "+filename+" iscreated  ");	

		
	}

}
