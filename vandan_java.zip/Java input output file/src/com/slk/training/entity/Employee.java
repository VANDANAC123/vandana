package com.slk.training.entity;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Employee implements Serializable{
	
	private int id;
	private double sal;
	private String name;
	
	public Employee()
	{
		
	}

	public Employee(int id, double sal, String name) {
		this.id = id;
		this.sal = sal;
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public double getSal() {
		return sal;
	}

	public void setSal(double sal) {
		this.sal = sal;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", sal=" + sal + ", name=" + name + "]";
	}
	
	

}
