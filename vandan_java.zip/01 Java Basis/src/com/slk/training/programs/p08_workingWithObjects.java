package com.slk.training.programs;

class point
{
	static
	{
		System.out.println("class point loaded");
	}
	int x,y,z;
	public String  toString() {
		 return "point[x="+x+ " y="+y+" z="+z+"]";
		
	}
	
}


public class p08_workingWithObjects {
	static
	{
		System.out.println("class p08_workingWithObjects ");
	}
	public static void main(String[] args)
	{
		System.out.println("creating a variable of type point....");
		// the class point is not loaded yet....
		point p1;
		System.out.println("creating an object of type point...");
		p1=new point();
		p1.x=20;
		p1.y=30;
		p1.z=34;
		//System.out.println(p1.x);
		System.out.println("p1 is :"+p1);
		System.out.println("end of main!!!");
	}

}
