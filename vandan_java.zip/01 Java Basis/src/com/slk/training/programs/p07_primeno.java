package com.slk.training.programs;

public class p07_primeno {
	static void whileLoopExample()
	{
		int n=17;
		int d=2,limit=n/2,rem;
		while(d<=limit)
		{
			rem=n%d;
		if(rem==0)
		{
			System.out.println(n+"  is not a prime");
		break;
		}
		d++;		
	}
	if(d>limit)

	{
		System.out.println(n+" is a prime");
	}
	}
	public static void main(String[] args)
	{
		whileLoopExample();
	}
}
