package com.slk.training.programs;

import com.slk.training.entity.person;


public class p15_WorkingWithStrings {
	public static void main(String[] args) {
		String s1="vandana";// create a new string object and stores in a cache
		String s2="vandana";
		System.out.println("s1==s2"+ (s1==s2));
		System.out.println("s1.equals(s2) is"+s1.equals(s2));
		System.out.println();
		s1=new String("kumar");
		s2=new String("kumar");
		System.out.println("s1==s2"+ (s1==s2));
		System.out.println("s1.equals(s2) is"+s1.equals(s2));
		person p1,p2;
		p1=new person();
		p2=new person();
		p1.setName("VANDANA");
		p2.setName("VANDANA");
		System.out.println("P1==P2"+ (p1==p2));
		System.out.println("s1.equals(s2) is"+p1.equals(p2));
		String text="my name is vandana";
		System.out.println("length of text is" +text.length());
		System.out.println(text.toUpperCase());
		System.out.println(text.substring(0,14));
		System.out.println(text);
		System.out.println("char of index 12 is:"+text.charAt(12));
		System.out.println("index of letter  V is:"+text.indexOf('v'));
		System.out.println("index of word bangalorw is:"+ text.indexOf("bangalore"));
		
		
		
		
		
		
		
		}
	

}
