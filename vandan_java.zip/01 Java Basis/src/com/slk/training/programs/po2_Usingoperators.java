package com.slk.training.programs;

public class po2_Usingoperators {

}
