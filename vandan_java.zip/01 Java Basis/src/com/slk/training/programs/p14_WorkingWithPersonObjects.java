package com.slk.training.programs;
import com.slk.training.entity.person;

public class p14_WorkingWithPersonObjects {
	
public static void main(String[] args) {
	
	person p1;
	p1=new person();
	p1.setName("VANDANA");
	p1.setAge(45);
	p1.setHeight(5.2);
	System.out.println("p1 is"+ p1);
	
	
}

}
