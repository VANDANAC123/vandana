package com.slk.training.programs;

public class p03_usingifelse {
	public static void example1()
	{
		int n=17;
		if(n %2==0)
			System.out.println(n+ " is an even");
		else
		System.out.println(n+"is an odd");		
	}
	
	static void ex2()
	{
		int m=0;
		if(m<1 ||m>12) 
			System.out.println("invalid month");
		else 
		{
			if(m==2)
			{
				System.out.println("28 or 29 days");
			}
			else if(m==4 || m==6||m==9 || m==11)
			{
				System.out.println("30 days");
			}
			else
			{
				System.out.println("31 days");
			}
		}
		
		
	}
	
public static void main(String[] args)
{
	example1();
	ex2();
}

}
