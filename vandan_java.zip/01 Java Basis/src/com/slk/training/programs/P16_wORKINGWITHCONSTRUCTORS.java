package com.slk.training.programs;
import com.slk.training.entity.person;

public class P16_wORKINGWITHCONSTRUCTORS {

	public static void main(String[] args) {
		
		person p1,p2,p3,p4;
		p1=new person();
		p2=new person("vandana");
		p3=new person("vandana",35);
		p4=new person("vandu",22);
		System.out.println(p1);
		System.out.println(p2);
		System.out.println(p3);
		System.out.println(p4);
		
		
		
		
	}

}
