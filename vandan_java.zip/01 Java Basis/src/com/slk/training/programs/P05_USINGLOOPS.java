package com.slk.training.programs;

public class P05_USINGLOOPS {
	
	static void flexm()
	{
		int n=67;
		for(int i=0;i<=10;i++)
		{
			System.out.printf("%d *%d=%d",n,i,n*i);
		}
	}

}
