package com.slk.training.programs;

public class p04_usingswitchcase {
	static int maxDays(int y,int m)
	{ 
		int max=0;
	
		switch(m)
		{
		case 2:
		if(y%400== 0 ||y%4 ==0 && y%100!=0)
		{
		max =29;
		}
		else 
		{
			max=28;
			
		}
		break;
		case 4: 
			case 6: 
				case 11: 
					case 9:
			max=30;
			break;
			default:
				max=31;
		}
		return max;
}
public static void main(String[] args) {
	int y=2016,m=12;
	 int z= maxDays(y,m);
	 System.out.println("the no of days is "+z);
}
}
		
	
		
		


