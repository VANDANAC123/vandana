package com.slk.training.programs;

public class HelloWorld {

public static void main(String[] args) {
	int b1;
	int a=4;
	b1=a++;
	System.out.println("value of a is"+ b1);
	float f=6.4544f;
	System.out.println("value of f is"+f);
	boolean isprime=true;
	System.out.println(" the no is prime  "  + isprime);
	
}
}
