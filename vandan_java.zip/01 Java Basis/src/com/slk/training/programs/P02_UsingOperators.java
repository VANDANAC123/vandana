package com.slk.training.programs;

public class P02_UsingOperators {
	public static void main(String[] args)
	{
	 int yr=2018;
	boolean isleap=((yr % 400==0) || (yr %4 ==0) && (yr % 100 !=0))
	
	System.out.println("year %d is % year",yr, is);
	}
}

