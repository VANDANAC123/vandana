package com.slk.training.programs;

public class p06_UsingLoops {
		
		static void forLoopExm()
		{
			int n=67;
			for(int i=1;i<=10;i++)
			{
				System.out.printf("%d *%d=%d\n ",n,i,n*i);
			}
		}

	public static void main(String[] args)
	{
		forLoopExm();
	}


}
