package com.slk.training.entity;

import java.util.Arrays;

public class p17_WorkingWithArrays {

	public static void main(String[] args) {
		int[] num;
		num=new int[5];
		
	num[0]=13;
	num[2]=45;
	System.out.println(" value of index 0 is:"+ num[0]);
	System.out.println(" value of index 1 is:"+ num[1]);
	System.out.println(" value of index 2 is:"+ num[2]);
	System.out.println(" value of index 3 is:"+ num[3]);
	System.out.println(" value of index 4 is:"+ num[4]);
	
	
	for( int i=0;i<num.length;i++) {
		System.out.printf(" value of index  %d is:%d\n",i, num[i]);
		
	}
	int sum=0;
	for(int n:num)
	{
		sum+=n;
	}
	System.out.println(" sum of all nos is:"+sum);
	
	num =new int[] {100,34,56,45,67};
	System.out.println(" value in num is:"+ Arrays.toString(num));
	}
	

}