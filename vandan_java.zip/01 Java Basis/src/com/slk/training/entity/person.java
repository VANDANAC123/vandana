package com.slk.training.entity;

public class person {
 private String name;
 private int age;
 private double height;
 
 
 public person()
 {
	 //adding a no _arg constructor is a good practice
 }
 
public person(String name, int age) {
	this.name = name;
	this.age = age;
}


public person(String name, double height) {
	this.name = name;
	this.height = height;
}



public person(String name) {
	this.name = name;
}






//getter property;a.k.a accessor
public String getName() {
	return name;
}
//setter property;a.k.a modifier
public void setName(String name) {
	this.name = name;
}

public int getAge() {
	return age;
}

public void setAge(int age) {
	if(age<1 || age>130) {
		throw new RuntimeException("invalid value for age . must be between 1 to 130");
	}
	this.age = age;
}

public double getHeight() {
	return height;
}

public void setHeight(double height) {
	this.height = height;
}

@Override
public String toString() {
	return "person [name=" + name + ", age=" + age + ", height=" + height + "]";
}


 
}
