package testing;

import java.util.TreeSet;

public class Hellohi extends Employee {

	public static void main(String[] args) {
		TreeSet<Employee> a = new TreeSet<Employee>();
		Employee e = new Employee(25);
		Employee e1 = new Employee(35);
		Employee e2 = new Employee(45);
		a.add(e);
		//a.add(e);
		//a.add(e);
		
		System.out.println(a);
	}
}
