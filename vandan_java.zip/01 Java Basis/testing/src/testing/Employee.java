package testing;

public class Employee {

	private int salary;

	public Employee() {

	}

	public Employee(int salary) {

		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [salary=" + salary + "]";
	}

}
