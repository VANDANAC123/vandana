package com.slk.assignment22.dao.impl;

import java.util.ArrayList;
import java.util.Date;

import java.util.List;

import com.slk.assignment22.dao.ContactsDao;
import com.slk.assignment22.dao.DaoException;
import com.slk.assignment22.entity.Contact;

public class ContactsDaoArrayListImpl implements ContactsDao {
	
	List<Contact> list; 
	
	

	public ContactsDaoArrayListImpl() {
		
		list=new ArrayList<>();
	}

	@Override
	public void addContact(Contact contact) throws DaoException {
		list.add(contact);
		
	}

	@Override
	public Contact getContact(int id) throws DaoException {
	return list.get(id);
	}

	@Override
	public void updateContact(Contact contact) throws DaoException {
		for(int i=0,j=list.size();i<j;i++) {
			Contact c=list.get(i);
			if(c.getId()== contact.getId()) {
				list.set(i, contact);
				break;
			}
		}
	}
		
	

	@Override
	public void deleteContact(int id) throws DaoException {
		for(int i=0,j=list.size();i<j;i++) {
			Contact c=list.get(i);
			if(c.getId()== id) {
				list.remove(id);
			}
		}
		
	}

	@Override
	public Contact getContactByEmail(String email) throws DaoException {
		for(Contact c:list) {
			if(c.getEmail()==email) {
				return c;
			}
		}
		return null;
	}

	@Override
	public Contact getContactByPhone(String phone) throws DaoException {
		for(Contact c:list) {
			if(c.getPhone()==phone) {
				return c;
			}
		}
		return null;
	}

	@Override
	public List<Contact> getContactsByLastname(String lastname) throws DaoException {
		List<Contact> lists=new ArrayList<Contact>();
		for(Contact c:list) {
			if(c.getLastname().equals(lastname)) {
				 lists.add(c);
			}
		}
		
		return lists;
	}

	@Override
	public List<Contact> getContactsByCity(String city) throws DaoException {
		List<Contact> lists=new ArrayList<Contact>();
		for(Contact c:list) {
			if(c.getCity()==city) {
				lists.add(c);
			}
		}
		return lists;
	}

	@Override
	public List<Contact> getContacts() throws DaoException {
		return list;
	}

	@Override
	public List<Contact> getContactsByBirthDate(Date from, Date to) throws DaoException {
		
		List<Contact> object =new ArrayList<>();
		for(Contact c:list) {
			Date dob= c.getBirthDate();
			if(dob.after(from) && dob.before(to)) {
			object.add(c);}
		}
		return object;
	
	}
	}
	
	


