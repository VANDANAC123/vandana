package com.slk.assignment22.dao.impl;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.slk.assignment22.dao.ContactsDao;
import com.slk.assignment22.dao.DaoException;
import com.slk.assignment22.entity.Contact;

public class ContactsDaoCsvImpl implements ContactsDao {
	
	String filename="contact.csv";
	
	FileReader file=new FileReader(filename);
	BufferedReader in=new BufferedReader(file);
	

private Map<Integer, Contact> map;


	

	public ContactsDaoCsvImpl() {
		map=new  HashMap<>();
		
	}

	@Override
	public void addContact(Contact contact) throws DaoException {
		

	}

	@Override
	public Contact getContact(int id) throws DaoException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateContact(Contact contact) throws DaoException {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteContact(int id) throws DaoException {
		// TODO Auto-generated method stub

	}

	@Override
	public Contact getContactByEmail(String email) throws DaoException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Contact getContactByPhone(String phone) throws DaoException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Contact> getContactsByLastname(String lastname) throws DaoException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Contact> getContactsByCity(String city) throws DaoException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Contact> getContacts() throws DaoException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Contact> getContactsByBirthDate(Date from, Date to) throws DaoException {
		// TODO Auto-generated method stub
		return null;
	}

}
