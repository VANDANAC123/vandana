package com.slk.assignment22.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;
import java.util.List;

import com.slk.assignment22.utils.DbUtil;
import com.slk.assignment22.utils.KeyboardUtil;
import com.slk.assignment22.dao.ContactsDao;
import com.slk.assignment22.dao.DaoException;
import com.slk.assignment22.entity.Contact;
import com.slk.assignment22.entity.Gender;

//import com.slk.assignment22.utils.DbUtil;
//import COM.SLK.TRAINING.UTIL.KeyBoardUtility;

public class ContactsDaoJdbcImpl implements ContactsDao {
	//int id;
	//String first_name,last_name,email,phone,address,city,state,country	;	
//	int pincode;
	//Gender gender;
	
	 Date birth_date;	
	


	@Override
	public void addContact(Contact contact) throws DaoException {
		String sql = "insert into CONTACT (id ,first_name, last_name, gender, email, phone, address, city, state, pincode, country, birth_date) values (?,?,?,?,?,?,?,?,?,?,?)";

		try(Connection conn=DbUtil.newConnection() ;
				PreparedStatement stmt=conn.prepareStatement(sql);
				){	
			
		
			while(true)
			{
				
			//	id=KeyboardUtil.getInt("enter the id:"+id);
			//	first_name=KeyboardUtil.getString("enter the first name:"+first_name);
			//	//last_name=KeyboardUtil.getString("enter the first name:"+last_name);
			//	if(contact.getGender().equals(Gender.MALE))
			//		KeyboardUtil.getString("MALE");
			//	else
				//	KeyboardUtil.getString("female");
				//gender=KeyboardUtil.getString("enter the gender:"+gender);
			//	email=KeyboardUtil.getString("enter the email:"+email);
			//	phone=KeyboardUtil.getString("enter the phone:"+phone);
				//address=KeyboardUtil.getString("enter the address:"+address);
			   //  city=KeyboardUtil.getString("enter the city:"+city);
			 //  state =KeyboardUtil.getString("enter the :"+state);
			  // pincode =KeyboardUtil.getInt("enter the :"+pincode);
			 //   country =KeyboardUtil.getString("enter the :"+country);
			    
			    
			    stmt.setInt(1,contact.getId());
			    stmt.setString(2,contact.getFirstname() );
			    stmt.setString(3, contact.getLastname());
			    
			    stmt.setString(4, contact.getGender().toString());
			    stmt.setString(5, contact.getEmail());
			    stmt.setString(6,contact. getPhone());
			    stmt.setString(7,contact. getAddress());
			    stmt.setString(8, contact.getCity());
			    stmt.setString(9, contact.getState());
			    stmt.setInt(10,contact. getPincode());
			    stmt.setString(11, contact.getCountry());
			    stmt.setDate(11, ( java.sql.Date)(contact.getBirthDate()));
			    
			    
			    stmt.executeUpdate();
				
				System.out.println("data inserted successfully");
				
		}
		}
							
		catch(Exception ex) {
			
		}

		}
	
	@Override
	public Contact getContact(int id) throws DaoException {
		String sql="select * from contact where id=?";
		
		try(Connection conn=DbUtil.newConnection() ;
				PreparedStatement stmt=conn.prepareStatement(sql);
				){	
			
			stmt.setInt(1, id);
			ResultSet rs=stmt.executeQuery();
			
			
			if(rs.next()) {
				do {
					
					first_name=rs.getString(2);
					last_name=rs.getString(3);
					
					gender =rs.getString(4);
					email=rs.getString(5);
					phone=rs.getString(6);
					address=rs.getString(7);
					city=rs.getString(8);
					state=rs.getString(9);
					pincode=rs.getInt(10);
					country=rs.getString(11);
					birth_date=rs.getDate(12);
					
	
				}while(rs.next());
			}
			else {
				System.out.println("no products found for the category:"+ category);
			}
		}
			
		
		
		
		
		
		
	}

	@Override
	public void updateContact(Contact contact) throws DaoException {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteContact(int id) throws DaoException {
		// TODO Auto-generated method stub

	}

	@Override
	public Contact getContactByEmail(String email) throws DaoException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Contact getContactByPhone(String phone) throws DaoException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Contact> getContactsByLastname(String lastname) throws DaoException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Contact> getContactsByCity(String city) throws DaoException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Contact> getContacts() throws DaoException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Contact> getContactsByBirthDate(Date from, Date to) throws DaoException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Contact> getContactsByBirthDate(java.util.Date from, java.util.Date to) throws DaoException {
		// TODO Auto-generated method stub
		return null;
	}

}
