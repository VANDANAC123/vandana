package com.slk.training.programs;

public class p17_ass7 {
	
	public static void power()
	{
		
	}

	public static void main(String[] args) {
		

	}

}
