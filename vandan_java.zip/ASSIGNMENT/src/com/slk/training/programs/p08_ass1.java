package com.slk.training.programs;

public class p08_ass1 {
	
	 static boolean isValidDate(int y,int m,int d)
	 {
		if(y%400 ==0 || y%4==0 && y%100 !=0)
		{
		
			
				if((d>=1 ||d<=29)&& (m==2))
				{
				return true;
				}
			
		}
		
		else if(m==11 ||m==4||m==6 || m==9)
		{
			if(d>=1 || d<=30)
			{
		return true;
			}
		}
		else if(m==1 ||m==3 ||m==5 ||m==7 ||m==8 || m==12)
		{
			if(d>=1 || d<=31)
		{
			return true;
		}
		}
		else 
		{
			return false;
		}
		
	return false;
	 }
	 
	 public static void main(String[] args)
	 { //int yr=2018,mo=2,ds=29;
		boolean z= isValidDate(2018,12,1);
		System.out.println(z);
		 
		 
	 }
}
		
		