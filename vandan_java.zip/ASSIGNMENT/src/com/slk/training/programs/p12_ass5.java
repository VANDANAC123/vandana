package com.slk.training.programs;

public class p12_ass5 {
	public  int sumOfNumbers(int from,int to)
	{
		int sum=0;
		
		for(int i=from;i<=to;i++)
		{
			int d=2,limit=i/2,rem;
			while(d<=limit)
			{
				rem=i%d;
			if(rem==0)
			{
				System.out.println(i+"  is not a prime");
			break;
			}
			d++;		
		}
		if(d>limit)

		{
		sum=sum+i;
		}
	
		}
		return sum;
	}
		public static void main(String[] args)
		{
			p12_ass5 p1=new p12_ass5();
			//p1.sumOfNumbers(10,20)
			System.out.println(p1.sumOfNumbers(10,20));
			
		}
}