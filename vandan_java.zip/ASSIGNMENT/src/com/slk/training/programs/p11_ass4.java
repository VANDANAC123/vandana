package com.slk.training.programs;

public class p11_ass4 {
	 static boolean isPrimeNumber(int num)
	 {
	
		
		int d=2,limit=num/2,rem;
		
			while(d<=limit)
			{
				rem=num%d;
			if(rem==0)
			{
				return false;
		
			}
			d++;		
		}
		if(d>limit)

		{
			return true;
		}
		return false;
		}
		public static void main(String[] args)
		{
			boolean z=isPrimeNumber(1);
			System.out.println(z);
		}
	

	 

}
