package com.slk.training.programs;

public class Assign14 {
	
	public static void printAllCombinations(String word) {
		
		char[] ch=word.toCharArray();
		char temp;
		String s1;
		String[] s3=null;
		
		for(int i=0;i<ch.length;i++)
		{
			for(int j=0;j<ch.length;j++)
			{
				temp=ch[i];
				ch[i]=ch[j];
				ch[j]=temp;
				s1=String.valueOf(ch);
				s1=new String(ch);
				
			}
			
			
		}
	}
	
	public static void main(String[] args)
	{
		String s2="win";
		
		printAllCombinations(s2);
		
		
	}
}
	


