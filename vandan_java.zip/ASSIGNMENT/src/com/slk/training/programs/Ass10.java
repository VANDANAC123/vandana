package com.slk.training.programs;

import java.util.Arrays;

public class Ass10 {
	
	public static int[] sumOfEvensAndOdds(int []nums) { 
		int[] b=new int[2];
		int sume=0,sumo=0;
		 
		for(int i=0;i<nums.length;i++) {
		if(nums[i]%2==0) {
			sume+=nums[i];
			
		}
		else {
			sumo+=nums[i];
		}
		}
		
		b[0]=sume;
		b[1]=sumo;
		
		
		return b;
		
	
		
		
	}


public static void main(String[] args)
{
	int a[]= {1,3,4,7,8,9,10};
	int[] result=new int[2];
	result=sumOfEvensAndOdds(a);
	System.out.println(Arrays.toString(result));
}
}
