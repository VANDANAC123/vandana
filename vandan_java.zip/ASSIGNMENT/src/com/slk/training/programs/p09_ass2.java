package com.slk.training.programs;

public class p09_ass2 {
	public  static void sortThreeNumbers(int a,int b,int c)
	{

		if(a>b && a>c)
		{
			if(b>c)
			{
				
				System.out.print("c"+c +"b"+b+"a"+a);
			}
			else
			{
				System.out.print("b"+b+"c"+c+"a"+a);
			}
		}
		else if(b>a && b>c)
			
		{
			if(a>c)
			{
				System.out.print("c"+c+"a"+a+"b"+b);
			}
			else
			{
				System.out.print("a"+a+"c"+c+"b"+b);
			}
		}
		else
		{
			if(a>b)
			{
				System.out.print("b"+b+"a"+a+"c"+c);
			}
			else
			{
				System.out.print("a"+a+"b"+b+"c"+c);
			}
		}	
		
	}
		public static void main(String[] args)
		{
			sortThreeNumbers(2,10,122);
			
		}
}

