package com.slk.entity;

public class Test21 {
	public static void main(String[] args) {
		
	
	
	Movable m3 = new MovableRectangle(1, 2, 3, 4, 25, 35);  // upcast
	System.out.println(m3);
	m3.moveUp();
	System.out.println(m3);
	}
	

}
