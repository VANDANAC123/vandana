package com.slk.entity;


public class MovableCircle implements Movable {
	
private	int radius=0;
 private  MovablePoint center;
 
 

 public MovableCircle(int radius, int x, int y, int xSpeed, int ySpeed) {
	 center=new MovablePoint( x,  y,  xSpeed, ySpeed);
        
        this.radius=radius;
 }
 
 




public void  moveUp()
{
	center.y-=center.ySpeed;
}

public void  moveDown() {
	center.y+=center.ySpeed;
}

public void  moveLeft()
{
	center.x-=center.xSpeed;
}

public void  moveRight()
{
	center.x+=center.xSpeed;
}


@Override
public String toString() {
	return "MovableCircle [radius=" + radius + ", center=" + center + ", toString()=" + super.toString() + "]";
}


}
