package com.slk.entity;

public class MovableRectangle implements Movable {
	
	private MovablePoint topleft;
	private MovablePoint bottomright;
	
	
	public MovableRectangle(int x1,int y1,int x2,int y2,int xspeed, int yspeed)
	{
		topleft=new MovablePoint(x1,y1,xspeed,yspeed);
		bottomright= new MovablePoint(x2,y2,xspeed,yspeed);
		
	}
	
	public void  moveUp()
	{
		topleft.y-=topleft.ySpeed;
		bottomright.y-=bottomright.ySpeed;
	}
	
	 
	 public void  moveDown()
	 {
		 topleft.y+=topleft.ySpeed; 
		 bottomright.y+=bottomright.ySpeed;
	 }
	 
	 public void  moveLeft() {
		 topleft.x-=topleft.xSpeed;
		 bottomright .x-=bottomright.xSpeed;
			 
	 }
	 
	 public void  moveRight() {
		 topleft.x+=topleft.xSpeed;
		 bottomright.x+=bottomright.xSpeed; 
	 }

	@Override
	public String toString() {
		return "MovableRectangle [topleft=" + topleft + ", bottomright=" + bottomright + ", toString()="
				+ super.toString() + "]";
	}
	 
}
	 

