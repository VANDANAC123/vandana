package com.slk.training.entity;

import java.util.Arrays;

public class p18_ass8 {
	

	public static int[] sumOfEvensAndOdds(int []nums) { 

		int[] n1=new int[2];
		int s1=0,s2=0;
		for(int i=0;i<nums.length;i++)
		{
			if(nums[i]%2==0)
			{
				s1+=nums[i];
				
			}
			else 
			{
				s2+=nums[i];
			}
		}
			n1[0]=s1;
			n1[1]=s2;
			
			return n1;
		
		
	

}
	public static void main(String[] args)
	{  
		int[] n2= {2,4,5,6,7};
		int[] result=sumOfEvensAndOdds(n2);
		System.out.println(" the value is"+Arrays.toString(result));
		
	
}
}
	

