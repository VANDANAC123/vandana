package com.slk.training.programs;

import com.slk.training.entity.Employee;
import com.slk.training.entity.Person;
import com.slk.training.entity.Student;
public class P02_TestingCasting {
	public static void main(String[] args) {
		Employee e2 = new Employee(2323, "vandu", "sdfhjshf@gmail.com", 343.56);
		Person p1=e2;
		Employee e3=(Employee) p1;
		System.out.println(e3);// it cannot be resolved
		// down casting must be explicit
		p1=new Student("vandu","sdjsk.com","maths",34.67);
		if(p1 instanceof Employee) {
		Employee e4=(Employee)p1;// explicit casting must be done conditionally
		System.out.println(e4);
		}
		
		
	}

}
