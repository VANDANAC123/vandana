package com.slk.training.programs;
import com.slk.training.entity.Employee;
import com.slk.training.entity.Person;
import com.slk.training.entity.Student;

public class P03_TestingPolymorphism {
	public static void main(String[] args) {
		Person[] people= {
				new Employee(12,"dff","gahsg.com",3455.99),
				new Employee(125,"dfff","gahsgdeeww.com",3444.99),
				new Student("sds","defd.com","sdsdsdd",45.78),
				new Employee(22,"dff","gahsg.com",34.99),
				new Student("hjh","dffdef","oipooio.com",90.99)
		
	};
		
		for(Person p:people)
		{
			System.out.printf("grade of %s is %s \n",p.getName(),p.getGrade());
		}
}
	

}
