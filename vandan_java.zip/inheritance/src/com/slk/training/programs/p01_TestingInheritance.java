package com.slk.training.programs;

import com.slk.training.entity.Employee;

public class p01_TestingInheritance {
	
	public static void main(String[] args) {
		
	
		Employee e1 = new Employee();
		e1.setName("vandana");
		e1.setEmail("vandana.45@gmail.com");

		System.out.println(e1);

		Employee e2 = new Employee(2323, "vandu", "sdfhjshf@gmail.com", 343.56);
		System.out.println(e2);
		
	
		
		
		
		
	}

}
