package com.slk.training.entity;

public class Professor {

}
