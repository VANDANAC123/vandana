package com.slk.training.entity;

public abstract class  P04_Abstract  extends Person{
	

}
