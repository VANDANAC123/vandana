package com.slk.training.entity;

import com.slk.training.programs.Person;

public class Student  extends Person{
	
	private String  subject;
	private double avgmarks;
	 Student()
	 {
	 }
	public Student(String name, String email, String subject, double avgmarks) {
		super(name, email);
		this.subject = subject;
		this.avgmarks = avgmarks;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public double getAvgmarks() {
		return avgmarks;
	}
	public void setAvgmarks(double avgmarks) {
		this.avgmarks = avgmarks;
	}
	 @Override
	public String getGrade() {
		
				if(avgmarks<40)
				{
					return "D";
				}
				else if(avgmarks<60)
				{
					return "C";
					
				}else if(avgmarks <80)
				{
					return "B";
					
				}else
				{
					return "A";
				}
	 }
}



