package com.slk.training.entity;

public class p19_ass9 {
	public static String reverseByWords(String sentence) { 
		
		//String[] n1=new String[50];
		String s1 = " ";
	     String[] a = sentence.split(" ");
		
		
			for(int j=a.length-1;j>=0;j--)
			{
				s1=s1+" "+a[j];
			
			}
		

			return s1; 
			
			}
	
	public static void main(String[] args)
	{
		String s2= "my name is vandana";
		System.out.println(reverseByWords(s2));
		
		
		
	}

}
