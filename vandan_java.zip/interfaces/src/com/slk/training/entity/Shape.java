package com.slk.training.entity;

public interface Shape {
	
	void printArea();
	

}
