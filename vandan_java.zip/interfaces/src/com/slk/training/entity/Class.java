package com.slk.training.entity;

public class Class {
	private double radius;

	public Class(double radius) {
		this.radius = radius;
	}

	public double getRadius() {
		return radius;
	}

	public void setRadius(double radius) {
		this.radius = radius;
	}
	public void printArea()
	{
		double area=Math.PI*radius*radius;
		System.out.println("Area of the circle is:"+area);
	}

}
