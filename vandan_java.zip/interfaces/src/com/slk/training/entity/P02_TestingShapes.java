package com.slk.training.entity;
import com.slk.training.entity.Triangle;
import com.slk.training.entity.Square;
import com.slk.training.entity.Shape;

public class P02_TestingShapes {
	
	public static void main(String[] args) {
		Shape[] objects= {
				new Triangle(22.0,12.5),
				new Triangle(12.0,34.0),
				new Square(22.34),
				
				
				
		};
		for(Shape s:objects)
		{
			s.printArea();
		}
		
	}

}
