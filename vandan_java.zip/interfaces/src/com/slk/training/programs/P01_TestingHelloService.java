package com.slk.training.programs;
import com.slk.training.service.HelloService;
import com.slk.training.service.Kannada;
import com.slk.training.service.EnglishHelloService;
import com.slk.training.service.Spanish;

public class P01_TestingHelloService {
	
	public static void main(String[] args) {
	 	 HelloService service;
	 	 
	 //	 service=HelloService()
//error ;interface is like a abstract class and cannot be instantiated
	 	
	 service =new EnglishHelloService();
			 service.greet();
	 
			 service =new Spanish();
			 service.greet();
			 
			 
			service =new Kannada();
			service.greet();
			 
	 	 
	}

}
