package com.slk.training.service;

public class Spanish implements HelloService {

	
	public void greet() {
		System.out.println("Hola amigo:"+ from);
	}

}
