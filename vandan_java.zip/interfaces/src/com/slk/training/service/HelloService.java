package com.slk.training.service;

public interface HelloService {
	
	String from="vandana";
	
	void greet();

	

}
