package com.slk.training.service;

public class EnglishHelloService implements HelloService {
	
	// if a class implements an interface, it inherits all 
	//the members from the interface,which typically 
	//include abstract functions, this means that 
	//the class must be daclared as abstract 
@Override
	public void greet() {
		System.out.println("hello friend!:"+ from);
	}

}
