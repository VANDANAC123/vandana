package com.slk.training.service;

public class Kannada implements HelloService {

	
	public void greet() {
		System.out.printf(" ಹಲೋ ಸ್ನೇಹಿತ\n ",from);
	}

}
	
	
