package com.slk.training.dao;
//import com.slk.training.dao.ProductDao1;
//import com.slk.training.dao.ProductDaoFILEimp1;

public class P03_TestingDao {
	public static void main(String[] args) {
		
	
		ProductDao1 Dao;
		//new ProductDaoFILEimp1();
		
		//it is the tight coupling
		//coupling depends on the specific implement
		//to avoid this ,we use the factory pattern
		//so factory method is also known as the virtual constructor,since it returns a newly 
		//constructed object   (instead of creating one)
		
	Dao=DaoFactory .newProductDao1();
		Dao.addProduct();
		 Dao. getProduct();
		Dao. updateProduct();
	Dao.deleteProduct();
	

}
}
