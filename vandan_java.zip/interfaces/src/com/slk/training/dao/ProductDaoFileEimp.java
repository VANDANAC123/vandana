package com.slk.training.dao;

import com.slk.training.service.HelloService;

public class ProductDaoFileEimp implements HelloService {

	@Override
	public void greet() {
		// TODO Auto-generated method stub

	}

}
