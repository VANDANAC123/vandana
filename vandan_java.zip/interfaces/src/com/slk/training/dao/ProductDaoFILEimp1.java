package com.slk.training.dao;

public class ProductDaoFILEimp1 implements ProductDao1 {

	@Override
	public void addProduct() {
		System.out.println("adding product into a file");
	}

	@Override
	public void getProduct() {
		System.out.println("adding product  details into a file");
	}

	@Override
	public void updateProduct() {
		System.out.println("adding product  details in a file");
	}

	@Override
	public void deleteProduct() {
		System.out.println("deleting  product into a file");

	}

}
