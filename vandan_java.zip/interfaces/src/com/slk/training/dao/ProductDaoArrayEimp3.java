package com.slk.training.dao;

public class ProductDaoArrayEimp3 implements ProductDao1 {

	@Override
	public void addProduct() {
		System.out.println("adding product into a array");
	}

	@Override
	public void getProduct() {
		System.out.println("adding product  details into a array ");
	}

	@Override
	public void updateProduct() {
		System.out.println("adding product  details in a array ");
	}

	@Override
	public void deleteProduct() {
		System.out.println("deleting product into a array");

	}

}
