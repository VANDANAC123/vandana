package com.slk.training.dao;

public class ProductDao {

}
