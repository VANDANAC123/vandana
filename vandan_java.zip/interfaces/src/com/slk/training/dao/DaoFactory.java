package com.slk.training.dao;

public final class DaoFactory {
	private DaoFactory()
	{
	}
	// this is a factory method
	//returns a newly cons
	public static ProductDao1 newProductDao1(String type) {
	 switch(type.toLowerCase())
	 {
	 case "jdbc":
		 return new ProductDaoDataimp2();
	 case "file":
		 return new ProductDaoFILEimp1();
	 case "array":
		 return new ProductDaoArrayEimp3();
		 default:
			throw new RuntimeException("invalid");
			
		 
	 }
	}
	
	public static ProductDao1 newProductDao1()
	{
		return newProductDao1("FASDHGS");
	}
	

}
