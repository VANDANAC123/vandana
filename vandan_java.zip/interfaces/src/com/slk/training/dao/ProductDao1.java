package com.slk.training.dao;

public interface ProductDao1 {
	//a dao interface contains crud and query operations
	
	//this is an exmple interface,without proper argument and return type
	 public void addProduct();// generally takes a product instance as argument
	 public void getProduct();//generally takes id as a argument
	 public void updateProduct();//generally takes a product instance as argument
	 public void deleteProduct();//generally takes id as argument
	 
	 // generally throws a exception
		
	

}
