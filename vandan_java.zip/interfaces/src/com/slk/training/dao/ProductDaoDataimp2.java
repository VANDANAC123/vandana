package com.slk.training.dao;

public class ProductDaoDataimp2 implements ProductDao1 {

	@Override
	public void addProduct() {
		System.out.println("adding product into a database table");
	}

	@Override
	public void getProduct() {
		System.out.println("adding product  details into a database table");
	}

	@Override
	public void updateProduct() {
		System.out.println("adding product  details in a database table");
	}

	@Override
	public void deleteProduct() {
		System.out.println("deleting product into a database table");

	}

}
