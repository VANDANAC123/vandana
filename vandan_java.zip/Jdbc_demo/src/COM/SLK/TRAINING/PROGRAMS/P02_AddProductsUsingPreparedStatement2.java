package COM.SLK.TRAINING.PROGRAMS;

import java.sql.Statement;

//import com.slk.assignment22.utils.DbUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import COM.SLK.TRAINING.UTIL.DbUtil;
import COM.SLK.TRAINING.UTIL.KeyBoardUtility;

public class P02_AddProductsUsingPreparedStatement2 {
	
	public static void main(String[] args){
		
	int id;
	String name;
	String category;
	double price;
	
	String sql="insert into products values(?,?,?,?)";
	try( Connection conn=DbUtil.newConnection() ;
			PreparedStatement stmt=conn.prepareStatement(sql);
	){	
		while(true)
		{
			id=KeyBoardUtility.getInt("enter the id");
			name=KeyBoardUtility.getString("enter the name");
			category=KeyBoardUtility.getString("enter the category");
			price=KeyBoardUtility.getDouble("enter the price");
			
		stmt.setInt(1,id);
		stmt.setString(2,name);
		 stmt.setString(3,category);
		 stmt.setDouble(4,price);
		
		stmt.executeUpdate();
		
			System.out.println("data inserted successfully");
			String choice=KeyBoardUtility.getString("do u want to add another?yes/no(yes):");
			if(choice.equalsIgnoreCase("no")) {
				break;
			}
		}
	}
	catch(Exception ex) {
		ex.printStackTrace();
	}

}
	}

