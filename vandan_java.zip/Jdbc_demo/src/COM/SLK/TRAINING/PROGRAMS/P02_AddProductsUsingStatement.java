package COM.SLK.TRAINING.PROGRAMS;

import java.sql.Statement;

import COM.SLK.TRAINING.UTIL.DbUtil;

import java.sql.Connection;
import java.sql.SQLException;

import COM.SLK.TRAINING.UTIL.KeyBoardUtility;

public class P02_AddProductsUsingStatement {
	
	public static void main(String[] args){
		
	int id;
	String name;
	String category;
	double price;
	
	
	try( Connection conn=DbUtil.newConnection() ;
			Statement stmt=conn.createStatement();
	){	
		while(true)
		{
			id=KeyBoardUtility.getInt("enter the id");
			name=KeyBoardUtility.getString("enter the name");
			category=KeyBoardUtility.getString("enter the category");
			price=KeyBoardUtility.getDouble("enter the price");
			
		String sql=String.format("insert into products values(%d,'%s','%s',%f)",
				id,name,category,price);
		stmt.executeUpdate(sql);
		
			System.out.println("data inserted successfully");
			String choice=KeyBoardUtility.getString("do u want to add another?yes/no(yes):");
			if(choice.equalsIgnoreCase("no")) {
				break;
			}
		}
	}
	catch(Exception ex) {
		ex.printStackTrace();
	}

}
	}

