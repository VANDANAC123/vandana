package COM.SLK.TRAINING.PROGRAMS;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import COM.SLK.TRAINING.UTIL.DbUtil;

import COM.SLK.TRAINING.UTIL.KeyBoardUtility;

public class P04_GetProductByCategory {
	
	public static void main(String[] args) {
		int id;
		String name;
		String category=KeyBoardUtility.getString("category") ;
		double price;
		
		String sql="select * from products where category=?";
		
		try(
				Connection conn=DbUtil.newConnection() ;
				PreparedStatement stmt=conn.prepareStatement(sql);
				){
			
			stmt.setString(1, category);
			ResultSet rs=stmt.executeQuery();
			
			if(rs.next()) {
				do {
					id=rs.getInt(1);
					name=rs.getString(2);
					price=rs.getDouble(4);
					System.out.println("name:"+name);
					System.out.println("id"+id);
					System.out.println("price:rs"+price);
					System.out.println();
				}while(rs.next());
			}
			else {
				System.out.println("no products found for the category:"+ category);
			}
			
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		
		
	}

}
